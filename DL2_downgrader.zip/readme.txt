If you don't have python installed
1. Open the Microsoft store 
2. Type in python
3. download a python interpreter namely. 3.13
4. wait a bit, then open my program